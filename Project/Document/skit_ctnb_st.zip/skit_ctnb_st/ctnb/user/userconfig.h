#ifndef __USERCONFIG_H__
#define __USERCONFIG_H__


/*********************************************************************************
*   server params config 
*
**********************************************************************************/


#define CTIOT_INIT_IP        "221.229.214.202"
#define CTIOT_INIT_PORT      5683
#define CTIOT_REG_LIFETIME   3600



#endif

