#ifndef _DELAY__H_
#define _DELAY__H_

#include <stdint.h>

void delay_us(unsigned int n);
void delay_ms(unsigned int n);

#endif
